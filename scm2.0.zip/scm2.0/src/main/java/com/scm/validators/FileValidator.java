package com.scm.validators;

import org.springframework.web.multipart.MultipartFile;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class FileValidator implements ConstraintValidator<ValidFile, MultipartFile> {
    private static final long MAX_FILE_SIZE = 1024 * 1024 * 2; // 2MB
    private static final int MAX_WIDTH = 1920;
    private static final int MAX_HEIGTH = 1080;

    @Override
    public boolean isValid(MultipartFile file, ConstraintValidatorContext context) {

        if (file == null || file.isEmpty()) {

            // context.disableDefaultConstraintViolation();
            // context.buildConstraintViolationWithTemplate("File cannot be
            // empty").addConstraintViolation();
            return true;

        }
        // file size
        System.out.println("file size: " + file.getSize());

        if (file.getSize() > MAX_FILE_SIZE) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("File size should be less than 2MB").addConstraintViolation();
            return false;
        }

        //check file type
        String contentType = file.getContentType();
        if (contentType == null || !(contentType.equals("image/jpeg") || contentType.equals("image/png"))) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Only JPEG and PNG files are allowed").addConstraintViolation();
            return false;
        }

        //check size and height
        try {
            BufferedImage bufferedImage = ImageIO.read(file.getInputStream());
            int height = bufferedImage.getHeight();
            int width = bufferedImage.getWidth();

            if (height > MAX_HEIGTH || width > MAX_WIDTH) {
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate("Image resolution should not exceed 1920x1080").addConstraintViolation();
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Error reading image file").addConstraintViolation();
            return false;
        }
        return true;
    }
}