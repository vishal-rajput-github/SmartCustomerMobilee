package com.scm.helper;

public enum MessageType {
    blue, red, green, yellow
}