console.log("script loaded");

let currentTheme = getTheme();

changeTheme();

function changeTheme() {
    document.querySelector("html").classList.add(currentTheme);
     const change = document.querySelector("#theme_change_button");
     change.querySelector("span").textContent = currentTheme == "light"?"dark" : "light";
     change.addEventListener("click", (event) => {
     console.log("change theme click here");
     const oldtheme = currentTheme;
     if(currentTheme === "dark") {
        currentTheme = "light";
     } else {
        currentTheme = "dark";
     }
     setTheme(currentTheme);
     document.querySelector("html").classList.remove(oldtheme);
     document.querySelector("html").classList.add(currentTheme);
 });
}

function setTheme(theme) {
 localStorage.setItem("theme", theme);
 }

 function getTheme() {
    let theme = localStorage.getItem("theme");
    if(theme) return theme;
    else return "light";
 }